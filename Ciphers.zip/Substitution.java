// Varun Panuganti
// 01/17/2024
// CSE 123 
// C0; Ciphers
// TA: Ido Avnon
import java.util.ArrayList;
import java.util.List;

//Overview of Class: This class extends the abstract class Cipher, and utilizes
//a shifter to encrypt and decrypt Strings
public class Substitution extends Cipher{
    /*
    The shifter is a string the same length of the character range used to encrypt
    and decrypt Strings
    */
    private String shifter;

    /*
    This method constructs an empty shifter
    */
    public Substitution(){
        this.shifter = "";
    }

    /*
    This method constructs a new shifter
    @param: The String used to construct the shifter
    Exceptions: Throws IllegalArgumentException if the shifter is empty
    */
    public Substitution(String shifter){
        if(shifter.isEmpty()){
            throw new IllegalArgumentException();
        }
        create(shifter);
    }

    /*
    This method assigns a new shifter
    @param: The String assigned as the shifter
    Exceptions: Throws IllegalArgumentException if the shifter is empty
    */
    public void setShifter(String shifter){
        if(shifter.isEmpty()){
            throw new IllegalArgumentException();
        }
        create(shifter);
    }

    /*
    This is a helper method used to construct a shifter
    @param: The String used to construct the shifter
    Exceptions: Illegal exception if the shifter isn't the right character length
    or there are duplicate letters, or one letter is outside the range
    */
    private void create(String shifter)throws IllegalArgumentException{
        boolean check = true;
        int iterate = 0;
        List<Character> letters = new ArrayList<Character>();
        while(iterate < shifter.length() && check){
            char check2 = shifter.charAt(iterate);
            int check1 = (int)check2;
            if(check1 < MIN_CHAR || MAX_CHAR < check1 || letters.contains(check2)){
                check = false;
            }else{
                letters.add(check2);
            }
            iterate++;
        }
        if(TOTAL_CHARS != shifter.length() || !check || shifter == null){
            throw new IllegalArgumentException();
        }
        this.shifter = shifter;
    }

    @Override
    /*
    This method overrides the encrypt method from the Cipher Abstract class
    It encrypts a message by using the given shifter, mapping from the original range 
    to the shifted range
    @param: The input being encrypted
    Return statement: The encrypted version of the input
    */
    public String encrypt(String input) {
        if(shifter.isEmpty()){
            throw new IllegalStateException();
        }
        String end = "";
        int size = input.length();
        for(int i = 0; i < size; i++){
            char current = input.charAt(i);
            int index = (int)current - MIN_CHAR;
            char encrypted = shifter.charAt(index);
            end += encrypted;
        }
        return end;  
    }

    @Override
    /*
    This method overrides the decrypt method from the Cipher Abstract class
    It decrypts a message by using the given shifter, mapping from the shifted range 
    to the original range
    @param: The input being decrypted
    Return statement: The decrypted version of the input
    */
    public String decrypt(String input) {
        if(shifter.isEmpty()){
            throw new IllegalStateException();
        }
        String end = "";
        int size = input.length();
        for(int i = 0; i < size; i++){
            char current = input.charAt(i);
            int index = MIN_CHAR + shifter.indexOf(current);
            char encrypted = (char) index;
            end += encrypted;
        }
        return end;
    }

}
