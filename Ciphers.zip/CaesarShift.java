// Varun Panuganti
// 01/17/2024
// CSE 123 
// C0; Ciphers
// TA: Ido Avnon
//Overview of Class: This class extends the abstract class Cipher, and shifts 
//every character in the shifter by how much the user wants
public class CaesarShift extends Cipher{
    //The amount that the shifter must be shifted from the original
    private int shift;

    /*
    This method is used to construct the shift amount for this object
    @param: The shift amount
    */
    public CaesarShift(int shift){
        this.shift = shift;
    }

    @Override
    /*
    This method overrides the encrypt method from the Cipher Abstract class
    It encrypts a message by shifting all the characters in the defined range to the left
    @param: The input being encrypted
    Return statement: The encrypted version of the input
    */
    public String encrypt(String input) {
        String end = "";
        int size = input.length();
        for(int i = 0; i < size; i++){
            int index = (int)input.charAt(i);
            char o = (char)(Cipher.MIN_CHAR + (index + shift - Cipher.MIN_CHAR) % Cipher.TOTAL_CHARS);
            end+=o;
        }
        return end;
    }

    @Override
    /*
    This method overrides the decrypt method from the Cipher Abstract class
    It decrypts a message by shifting all the characters in the defined range to the right
    @param: The input being decrypted
    Return statement: The decrypted version of the input
    */
    public String decrypt(String input) {
        String end = "";
        int size = input.length();
        for(int i = 0; i < size; i++){
            int index = (int)input.charAt(i);
            int a = (Cipher.MIN_CHAR + (index - Cipher.MIN_CHAR - shift + Cipher.TOTAL_CHARS) % Cipher.TOTAL_CHARS);
            if((index - Cipher.MIN_CHAR - shift + Cipher.TOTAL_CHARS)% Cipher.TOTAL_CHARS<0){
                a += Cipher.TOTAL_CHARS;
            }
            char c = (char)a;
            end+=c;
        }
        System.out.println(end);
        return end;
    }

}
