// Varun Panuganti
// 01/17/2024
// CSE 123 
// C0; Ciphers
// TA: Ido Avnon
import java.util.ArrayList;
import java.util.List;

//Overview of Class: This class extends the abstract class Cipher, and hosts a 
//list of Cipers to perform a series of encryptions/decryptions
public class MultiCipher extends Cipher{
    /*
    This is the list of Ciphers that the MultiCipher iterates through
    */
    private List<Cipher> ciphers;

    /*
    This constructor constructs the list of Ciphers using a given list of Ciphers
    @param: An ArrayList of Ciphers that are iterated through
    Exceptions: Throw IllegalArgumentException if the cipher list is null or empty
    */
    public MultiCipher(List<Cipher> ciphers)throws IllegalArgumentException{
        if(ciphers == null || ciphers.isEmpty()){
            throw new IllegalArgumentException();
        }
        this.ciphers = new ArrayList<Cipher>();
        this.ciphers.addAll(ciphers);
    }

    @Override
    /*
    This method overrides the encrypt method from the Cipher Abstract class
    It encrypts a message by using the list of ciphers constructed
    The ciphers pass down their encryptions to each other, creating a multilayer encryption
    @param: The input being encrypted
    Return statement: The encrypted version of the input
    */
    public String encrypt(String input) {
        //System.out.println("Before:");
        System.out.println();
        for(Cipher cipher : ciphers){
            System.out.println("encryption");
            System.out.println(input);
            input = cipher.encrypt(input);
        }
        return input;
    }

    @Override
    /*
    This method overrides the decrypt method from the Cipher Abstract class
    It decrypts a message by using the list of ciphers constructed
    The ciphers pass down their decryptions to each other, working in the reverse order of 
    the encryption method, creating a multilayer decryption
    @param: The input being decrypted
    Return statement: The decrypted version of the input
    */
    public String decrypt(String input) {
        for(int i = ciphers.size()-1; i >= 0; i--){
            Cipher cipher = ciphers.get(i);
            input = cipher.decrypt(input);
        }
        return input;
    }

}
