// Varun Panuganti
// 01/17/2024
// CSE 123 
// C0; Ciphers
// TA: Ido Avnon
import java.util.ArrayList;
import java.util.List;

//Overview of Class: This class extends the abstract class Cipher, and uses
//a key to create a shifter that is used for encryption and decryption
public class CaesarKey extends Cipher{
    //This is the key of characters that are moved to the front of the shifter
    private String key;

    /*
    This method is used to construct a key
    @param: A String key which is consisting of the characters which will be moved to 
    the front of the shifter
    Exceptions: throws an exception if the key is empty or any of its characters are not unique
    or aren't in the acceptable range
    */
    public CaesarKey(String key)throws IllegalArgumentException{
        boolean check = true;
        int iterate = 0;
        List<Character> letters = new ArrayList<Character>();
        // System.out.println(key);
        while(iterate < key.length() && check){
            char check2 = key.charAt(iterate);
            int check1 = (int)check2;
            if(check1 < Cipher.MIN_CHAR || Cipher.MAX_CHAR < check1 || letters.contains(check2)){
                check = false;
            }else{
                letters.add(check2);
            }
            iterate++;
        }
        if(key.isEmpty() || !check){
            throw new IllegalArgumentException();
        }
        this.key = key;
    }

    @Override
    /*
    This method overrides the encrypt method from the Cipher Abstract class
    It encrypts messages using a shifter created by the key, mapping from the original range 
    to the shifted range
    @param: The input being encrypted
    Return statement: The encrypted version of the input
    */
    public String encrypt(String input) {
        System.out.println("encryption");
        String shifter = getShifter();
        String end = "";
        int size = input.length();
        for(int i = 0; i < size; i++){
            char current = input.charAt(i);
            int index = (int)current - Cipher.MIN_CHAR;
            char encrypted = shifter.charAt(index);
            end += encrypted;
        }
        return end;  
    }

    @Override
    /*
    This method overrides the decrypt method from the Cipher Abstract class
    It decrypts messages using a shifter created by the key, mapping from the shifted range 
    to the original range
    @param: The input being decrypted
    Return statement: The decrypted version of the input
    */
    public String decrypt(String input) {
        System.out.println("decryption");
        String shifter = getShifter();
        String end = "";
        int size = input.length();
        for(int i = 0; i < size; i++){
            char current = input.charAt(i);
            int index = Cipher.MIN_CHAR + shifter.indexOf(current);
            char encrypted = (char) index;
            end += encrypted;
        }
        return end;
    }

    /*
    This is a helper method used to create the shifter used for encryption and decryption
    Return statement: The shifter created using the key
    */
    private String getShifter(){
        String shifter = key;
        for(int i = Cipher.MIN_CHAR; i <= Cipher.MAX_CHAR; i++){
            char check = (char)(i);
            if(!(key.contains(String.valueOf(check)))){
                shifter+=check;
            }
        }
        return shifter;
    }
}
