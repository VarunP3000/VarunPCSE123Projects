import java.util.*;

//Class used to interact with a calculator
public class Client {
    public static void main(String[] args) {
        Calculator c = new Calculator();
        Scanner in = new Scanner(System.in);
        prompt();
        String input = in.nextLine();
        while (!input.equalsIgnoreCase("quit")) {
            String[] arguments = input.split(" ");
            String operation = arguments[0];
            if (operation.equalsIgnoreCase("clear")) {
                c.clear();
            } else if (operation.equalsIgnoreCase("load")) {
                c.load(Integer.parseInt(arguments[1]));
            } else if (operation.equalsIgnoreCase("add")) {
                if (arguments.length == 2) {
                    c.add(Integer.parseInt(arguments[1]));
                } else {
                    c.add(Integer.parseInt(arguments[1]), Integer.parseInt(arguments[2]));
                }
            } else if (operation.equalsIgnoreCase("multiply")) {
                if (arguments.length == 2) {
                    c.multiply(Integer.parseInt(arguments[1]));
                } else {
                    c.multiply(Integer.parseInt(arguments[1]), Integer.parseInt(arguments[2]));
                }
            }
            System.out.println("Value: " + c.result());
            System.out.println();
            prompt();
            input = in.nextLine();
        }
        c.printStats();
    }

    //prints a prompt to the user with options for calculator operations
    public static void prompt() {
        System.out.println("What operation would you like to do?");
        System.out.println();
        System.out.println("Available Operations: clear, load, add, multiply, quit");
        System.out.println("You can add and multiply one number to the current number");
        System.out.println("or input two numbers to clear the current result");
        System.out.println();
    }
}
