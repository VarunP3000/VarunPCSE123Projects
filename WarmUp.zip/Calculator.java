// James Wilcox
// TA: Brett Wortzman
// CSE 123
// P0: Feedback prep
//
// A class representing a calculator which stores the result of the previous operation.
// Contains functionality for adding and multiplying integers
public class Calculator {
    private int saved;
    private int numOps;

    //Constructors a new, blank calculator
    public Calculator() {
        saved = 0;
        numOps = 0;
    }

    //Loads the given number into the calculator
    public void load(int num) {
        saved = num;
        numOps++;
    }

    //Clears the currently stored number
    public void clear() {
        saved = 0;
        numOps++;
    }

    //Adds the given number to the currently stored number
    public void add(int num) {
        saved += num;
        numOps++;
    }

    //Adds the two given numbers together, replacing the result
    //with the currently stored number
    public void add(int num1, int num2) {
        saved = num1 + num2;
        numOps++;
    }

    //Multiplies the given number to the currently stored number
    public void multiply(int num) {
        saved *= num;
        numOps++;
    }

    //Multiplies the two given numbers together, replacing the result
    //with the currently stored number
    public void multiply(int num1, int num2) {
        saved = num1 + num2;
        numOps++;
    }

    //Returns the currently stored number
    public int result() {
        return saved;
    }

    //Prints to the console statistics about the currently stored number
    //and the total number of operations executed on this calculator
    public void printStats() {
        System.out.println("This is my calculator!");
        System.out.println("I think its super cool!");
        System.out.println("Last Saved Result: " + result());
        System.out.println("Number of Operations: " + numOps); 
    }
}
