#! /bin/bash

javac *.java && java Client || rm *.class
