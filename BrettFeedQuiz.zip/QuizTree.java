// Varun Panuganti
// 3/10/2024
// CSE 123 
// BrettFeed Quiz
// TA: Ido Avnon
import java.io.PrintStream;
import java.util.Random;
import java.util.Scanner;

//This class implements the functionality of a quiz, in which a series of questions with two
//choices are asked. Each choice leads to another question until a result is reached. Each choice
//and result is associated with points, and the sum of the points from the path that the user
//takes through their quiz is totaled and is the users final score.
public class QuizTree {
    //This is the first question of the quiz
    private QuizTreeNode root;

    //This method creates a quiz using a given text file. The text file must be ordered in a
    //pre-order traversal of the quiz that the user desires to create.
    /*
    @param: 
    InputFile: the Scanner used to read the text file
    */
    public QuizTree(Scanner InputFile){
        this.root = quizTreeHelper(InputFile);
    }

    //This is a helper method used by the QuizTree constructor that reads a text file
    //into a QuizTree. The text file must be ordered in a pre-order traversal of the quiz that the
    //user desires to create.
    /*
    @param: 
    input: the scanner used to read the text file
    Return Statement: A QuizTreeNode being added to the tree
    */
    private QuizTreeNode quizTreeHelper(Scanner input){
        String node = input.nextLine();
        QuizTreeNode root = createNode(node);
        if(!node.contains("END:")){
            root.leftChoice = quizTreeHelper(input);
            root.rightChoice = quizTreeHelper(input);
        }else{
            root = createNode(node.replace("END:", ""));
        }
        return root;
    }

    //This method exports the QuizTree into a text file using a pre-order traversal.
    /*
    @param: The file that the QuizTree is being written into
    */
    public void export(PrintStream outputFile){
        exportHelper(root, outputFile);
    }

    //This is a helper method used by the export method that exports a QuizTree 
    //into a text file using a pre-order traversal.
    /*
    @param: 
    root: The QuizTreeNode being printed into the text file
    outputFile: The file that the QuizTree is being written into
    */
    private void exportHelper(QuizTreeNode root, PrintStream outputFile){
        if(root!=null){
            outputFile.println(root.toString());
            exportHelper(root.leftChoice, outputFile);
            exportHelper(root.rightChoice, outputFile);
        }
    }

    //This method allows the user to add questions to the quiz, a question can only be added in
    //the place of a result. If the result that the user wants to replace does not exist then no
    //question is added.
    /*
    @param: 
    toReplace: The result QuizTreeNode being replaced
    choices: The choices of the question that is being added
    leftResult: The result that the first choice in the question leads to
    rightResult: The result that the second choice in the question leads to
    */
    public void addQuestion(String toReplace, String choices, String leftResult, 
    String rightResult){
        root = addQuestionHelper(root, toReplace, choices, leftResult, rightResult);
    }

    //This is a helper method for addQuestion, that replaces a result in the quiz with another 
    //question
    /*
    @param:
    root: The QuizTreeNode being checked to see if it is a result and can be replaced
    toReplace: The result that the user desires to replace
    choices: The choices in the new question the user wants to add
    Return Statement: The QuizTreeNode that is being added to the QuizTree
    */
    private QuizTreeNode addQuestionHelper(QuizTreeNode root, String toReplace, String choices, 
    String leftResult, String rightResult){
        if(root.rightChoice == null && root.leftChoice == null){
            String description = root.description;
            if(description.equalsIgnoreCase(toReplace)){
                QuizTreeNode replacement = createNode(choices);
                replacement.leftChoice = createNode(leftResult);
                replacement.rightChoice = createNode(rightResult);
                return replacement;
            }
        }else{
            root.leftChoice = 
            addQuestionHelper(root.leftChoice, toReplace, choices, leftResult, rightResult);
            root.rightChoice = 
            addQuestionHelper(root.rightChoice, toReplace, choices, leftResult, rightResult);
        }
        return root;
    }

    //This method allows the user to take the Quiz. They can choose between two options in each
    //question, which leads them to a result. For the path that they take, they are also given a
    //point score.
    /*
    @param:
    console: The Scanner used to read input
    */
    public void takeQuiz(Scanner console){
        takeQuizHelper(console, root, 0);
    }

    //This method is a helper method for takeQuiz which allows the user to choose different 
    //options in the quiz to get to a certain outcome and have a score for their outcome.
    /*
    @param:
    console: The scanner being used to read input
    root: The current question of the quiz that the user is on
    score: The users score so far in their journey throughout the quiz
    */
    private void takeQuizHelper(Scanner console, QuizTreeNode root, int score){
        score+=root.score;
        if(root.leftChoice != null && root.rightChoice != null){
            String description = root.description;
            String[] choices = description.split("/");
            String choice1 = choices[0];
            String choice2 = choices[1];
            System.out.print("Do you prefer " + choice1 + " or " + choice2 + "? ");
            String answer = console.nextLine();
            if(answer.equals(choice1)){
                takeQuizHelper(console, root.leftChoice, score);
            }else if(answer.equals(choice2)){
                takeQuizHelper(console, root.rightChoice, score);
            }
        }else{
            System.out.println("Your result is: " + root.description);
            System.out.println("Your score is: " + score);
        }
    }

    //This method allows the user to take the quiz but also allows them to add a cuttoff point.
    //Once this cutoff point is reached, the path that the rest of the quiz takes is randomized
    //and no longer up to the user. Therefore the final result and score that the user obtains
    //is also randomized.
    /*
    @param:
    console: The scanner used to read input
    */
    public void creativeExtension(Scanner console){
        System.out.print("What is your cutoff?");
        String cutoff = console.nextLine();
        int cutOff = Integer.parseInt(cutoff);
        Random rand = new Random();
        creativeExtensionHelper(console, root, 0, 1, cutOff, rand);
    }

    //This is a helper method used by the method CreativeExtension. This method allows the user
    //to answer questions in the quiz until they reach a cuttoff point that they choose, after
    //the outcome of the quiz is randomized.
    /*
    @param: 
    console: The scanner used to read input
    root: The current question that the user is on
    score: The users score so far in their journey throughout the quiz
    curr: The amount of questions that the user has completed
    rand: The object used to help randomize the answer choice for each question
    */
    private void creativeExtensionHelper(Scanner console, QuizTreeNode root, int score, 
    int curr, int cutOff, Random rand){
        score+=root.score;
        if(root.leftChoice != null && root.rightChoice != null){
            String description = root.description;
            String[] choices = description.split("/");
            String choice1 = choices[0];
            String choice2 = choices[1];
            String answer = "";
            if(curr == cutOff){
                System.out.println("You have reached the cutoff");
            }
            if(curr<cutOff){
                System.out.println("Do you prefer " + choice1 + " or " + choice2 + "?");
                answer = console.nextLine();
            }else{
                int choice = rand.nextInt(2);
                answer = choices[choice];
            }
            if(answer.equals(choice1)){
                creativeExtensionHelper(console, root.leftChoice, score, curr+1, cutOff, rand);
            }else if(answer.equals(choice2)){
                creativeExtensionHelper(console, root.rightChoice, score, curr+1, cutOff, rand);
            }
        }else{
            System.out.println("Your result is: " + root.description);
            System.out.println("Your score is: " + score);
        }
    }

    //This method is used to create a QuizTreeNode given a description of a question
    //which includes its choices and score.
    /*
    @param:
    description: The description of the question
    */
    private QuizTreeNode createNode(String description){
        String[] split = description.split("-");
        String result = split[0];
        String stringScore = split[1];
        int score = Integer.parseInt(stringScore);
        QuizTreeNode node = new QuizTreeNode(score, result);
        return node;
    }

    // PROVIDED
    // Returns the given percent rounded to two decimal places.
    private double roundTwoPlaces(double percent) {
        return (double) Math.round(percent * 100) / 100;
    }

    //This class implements the functionality of a node in a quiz tree, which includes
    //the question and its score
    private static class QuizTreeNode{
        //This is the QuizTreeNode which is the leftchoice of the question of the QuizTreeNode
        public QuizTreeNode leftChoice;
        //This is the QuizTreeNode which is the rightchoice of the question of the QuizTreeNode
        public QuizTreeNode rightChoice;
        //This is the description of the QuizTreeNode which is either the name of the end result
        //or the choices if the QuizTreeNode is a question
        final public String description;
        //This is the score of the QuizTreeNode
        final public int score;

        //This method constructs a QuizTreeNode with a given score and description.
        /*
        @param: 
        score: The score of the QuizTreeNode
        description: the name of the result or the choices if it is a question
        */
        public QuizTreeNode(int score, String description){
            this.score = score;
            this.description = description;
        }

        //This method returns the QuizTreeNode in the form of a String.
        /*
        Return Statement: The score and description of the QuizTreeNode
        */
        public String toString(){
            if(rightChoice == null && leftChoice == null){
                return ("END: " + description+"-"+score);
            }
            return (description+"-"+score);
        }
    }
}
